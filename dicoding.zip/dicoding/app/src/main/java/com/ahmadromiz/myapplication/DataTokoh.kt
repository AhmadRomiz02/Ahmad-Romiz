package com.ahmadromiz.myapplication

object DataTokoh {private val namaTokohk = arrayOf(
        "Syech Muhammad Arsyad Al-Banjari",
        "Muhammad Zaini bin Abdul Ghani Al-Banjari",
        "Dr. K. H. Abdurrahman Wahid (GUSDUR)",
        "KH. Baha’uddin Nursalim",
        "Ustaz Abdul Somad Batubara, Lc., D.E.S.A.",
        "al-Habib Umar bin Muhammad bin Salim bin Hafidz",
        "Habib Munzir bin Fuad al-Musawa",
        "Ahmad Romiz",
        "Habib Muhammad Rizieq bin Hussein Shihab, Lc., M.A., DPMSS",
        "Habib Syech Abdul Qodir Assegaf"


)

    private val detaillTokoh = arrayOf(
        " al-Syaikh Muhammad Arsyad bin 'Abdullāh bin 'Abdurraḥman al-Banjarī (bahasa Arab: الشيخ محمد أرشد بن عبدالله بن عبدالرحمن البنجري) lahir di Lok Gabang, 17 Maret 1710 meninggal di Dalam Pagar, 3 Oktober 1812 pada umur 102 tahun) ulama fiqih mazhab Syafi'i yang berasal dari kota Martapura di Tanah Banjar (Kesultanan Banjar), Kalimantan Selatan. Dia hidup pada masa tahun 1122-1227 hijriyah. Dia disebut juga Haji Besar dan mendapat julukan anumerta Datu Kalampaian. Kitab karya Syekh Muhammad Arsyad yang paling terkenal ialah Kitab Sabilal Muhtadin, atau selengkapnya adalah Kitab Sabilal Muhtadin lit-tafaqquh fi amriddin, yang artinya dalam terjemahan bebas adalah Jalan bagi orang-orang yang mendapat petunjuk untuk mendalami urusan-urusan agama. Syekh Muhammad Arsyad telah menulis untuk keperluan pengajaran serta pendidikan, beberapa kitab serta risalah lainnya, di antaranya ialah:[20]\n" +
                "\n-Kitab Ushuluddin yang biasa disebut Kitab Sifat Duapuluh,\n" +
                "-Kitab Tuhfatur Raghibin, yaitu kitab yang membahas soal-soal itikad serta perbuatan yang sesat,\n" +
                "-Kitab Nuqtatul Ajlan, yaitu kitab tentang wanita serta tertib suami-isteri,\n" +
                "-Kitabul Fara-idl, hukum pembagian warisan.\n" +
                "Dari beberapa risalahnya dan beberapa pelajaran penting yang langsung diajarkannya, oleh murid-muridnya kemudian dihimpun dan menjadi semacam Kitab Hukum Syarat, yaitu tentang syarat syahadat, sembahyang, bersuci, puasa dan yang berhubungan dengan itu, dan untuk mana biasa disebut Kitab Parukunan. Sedangkan mengenai bidang Tasawuf, ia juga menuliskan pikiran-pikirannya dalam Kitab Kanzul-Makrifah."
        ,"Kyai Haji Muhammad Zaini Abdul Ghani memiliki gelar pada kalangan ulama yaitu :\n" +
                "-Syaikhuna al-Alim al-Allamah Muhammad Zaini bin al-Arif billah Abdul Ghani\n" +
                "-Syaikhuna al-Alim al-Allamah al-Arif billaah al-Bahr al-Ulum al-Waliy al-Qutb As-Syaikh al-Mukarram Maulana Muhammad Zaini bin Abdul Ghani al-Banjari\n" +
                "\nDilahirkan pada Rabu 11 Februari 1942 (27 Muharram 1361 Hijriyah) di desa Tunggul Irang, Martapura, Kabupaten Banja\n" +
                "Meninggal dunia pada Rabu 10 Agustus 2005 (63 tahun) di komplek pengajian, Sekumpul Martapura.\n" +
                "\n Karya tulis beliau yaitu:\n" +
                "-Risalah Mubaraqah.\n" +
                "\n-Manaqib Asy-Syekh As-Sayyid Muhammad bin Abdul Karim Al-Qadiri Al-Hasani As-Samman Al-Madani.\n" +
                "\n-Ar-Risalatun Nuraniyah fi Syarhit Tawassulatis Sammaniyah.\n" +
                "\n-Nubdzatun fi Manaqibil Imamil Masyhur bil Ustadzil a’zham Muhammad bin Ali Ba’alawy.\n" +
                "\n\nSalah satu pesan Guru Sekumpul adalah tentang karamah, yakni agar kita jangan sampai tertipu dengan segala keanehan dan keunikan. Karena bagaimanapun juga karamah adalah anugrah, murni pemberian, bukan suatu keahlian atau skill. Karena itu jangan pernah berpikir atau berniat untuk mendapatkan karamah dengan melakukan ibadah atau wiridan-wiridan. Dan karamah yang paling mulia dan tinggi nilainya adalah istiqamah di jalan Allah itu sendiri. Kalau ada orang mengaku sendiri punya karamah tetapi salatnya tidak karuan, maka itu bukan karamah, tetapi bakarmi (orang yang keluar sesuatu dari duburnya)."
        ,"Dr.(H.C.) K. H. Abdurrahman Wahid atau yang akrab disapa Gus Dur\n" +
                "\nlahir di Jombang, Jawa Timur, 7 September 1940\n" +
                "\nmeninggal di Jakarta, 30 Desember 2009 (69 tahun)\n" +
                "\n\nGusdur adalah tokoh Muslim Indonesia dan pemimpin politik yang menjadi Presiden Indonesia yang keempat dari tahun 1999 hingga 2001. Ia menggantikan Presiden B.J. Habibie setelah dipilih oleh Majelis Permusyawaratan Rakyat hasil Pemilu 1999. Penyelenggaraan pemerintahannya dibantu oleh Kabinet Persatuan Nasional. Masa kepresidenan Abdurrahman Wahid dimulai pada 20 Oktober 1999 dan berakhir pada Sidang Istimewa MPR pada tahun 2001. Tepat 23 Juli 2001, kepemimpinannya digantikan oleh Megawati Soekarnoputri setelah mandatnya dicabut oleh MPR. Abdurrahman Wahid adalah mantan ketua Tanfidziyah (badan eksekutif) Nahdlatul Ulama dan pendiri Partai Kebangkitan Bangsa (PKB).\n" +
                "\nGus Dur juga banyak memperoleh gelar Doktor Kehormatan (Doktor Honoris Causa) dari berbagai lembaga pendidikan:\n" +
                "\n-Doktor Kehormatan bidang Filsafat Hukum dari Universitas Thammasat, Bangkok, Thailand (2000)\n" +
                "\n-Doktor Kehormatan dari Asian Institute of Technology, Bangkok, Thailand (2000)\n" +
                "\n-Doktor Kehormatan bidang Ilmu Hukum dan Politik, Ilmu Ekonomi dan Manajemen, dan Ilmu Humaniora dari Pantheon Universitas Sorbonne, Paris, Prancis (2000)\n" +
                "\n-Doktor Kehormatan dari Universitas Chulalongkorn, Bangkok, Thailand (2000)\n" +
                "\n-Doktor Kehormatan dari Universitas Twente, Belanda (2000)\n" +
                "\n-Doktor Kehormatan dari Universitas Jawaharlal Nehru, India (2000)\n" +
                "\n-Doktor Kehormatan dari Universitas Soka Gakkai, Tokyo, Jepang (2002)\n" +
                "\n-Doktor Kehormatan bidang Kemanusiaan dari Universitas Netanya, Israel (2003)\n" +
                "\n-Doktor Kehormatan bidang Hukum dari Universitas Konkuk, Seoul, Korea Selatan (2003)\n" +
                "\n-Doktor Kehormatan dari Universitas Sun Moon, Seoul, Korea Selatan (2003)"
        ,"\tK.H. Ahmad Bahauddin Nursalim atau lebih dikenal dengan Gus Baha' adalah salah satu ulama Nahdlatul Ulama' (NU) yang berasal dari Narukan, Kragan, Rembang, Jawa Tengah. Gus Baha' dikenal sebagai salah satu Ulama ahli tafsir yang memiliki pengetahuan mendalam seputar al-Qur'an.\n" +
                "\nIa adalah putra seorang ulama' ahli Al-Qur'an, yakni KH. Nursalim Al-Hafizh, dari Narukan, Kragan, Rembang, Jawa Tengah, sebuah desa di pesisir utara pulau Jawa. KH. Nursalim adalah murid dari KH. Arwani Al-Hafidz Kudus dan KH. Abdullah Salam Al-Hafidz Pati.\n" +
                "\nDari silsilah keluarga ayah beliau inilah terhitung dari buyut beliau hingga generasi ke-empat kini merupakan ulama'-ulama' ahli Al-Qur'an yang handal. Silsilah keluarga dari garis ibu beliau merupakan silsilah keluarga besar ulama' Lasem, Bani Mbah Abdurrahman Basyaiban atau Mbah Sambu yang pesareannya ada di area Masjid Jami' Lasem, sekitar setengah jam perjalanan dari pusat Kota Rembang.\n" +
                "\n\tGus Baha' kecil mulai menempuh gemblengan keilmuan dan hafalan Al-Qur'an dibawah asuhan ayahnya sendiri. Pada usia yang masih sangat belia, beliau telah mengkhatamkan Al-Qur'an beserta Qiro'ahnya dengan lisensi yang ketat dari ayah beliau. Memang, karakteristik bacaan dari murid-murid Mbah Arwani menerapkan keketatan dalam tajwid dan makhorijul huruf.\n" +
                "\nMenginjak usia remaja, Kiai Nursalim menitipkan Gus Baha' untuk mondok dan berkhidmah kepada Syaikhina KH. Maimoen Zubair di Pondok Pesantren Al-Anwar Karangmangu, Sarang, Rembang, sekitar 10 km arah timur Narukan. Di Al-Anwar inilah beliau terlihat sangat menonjol dalam fan-fan ilmu syari'at seperti Fiqih, Hadits dan Tafsir."
        ,"Ustaz Abdul Somad Batubara, Lc., D.E.S.A.\n" +
                "\nlahir di Silo Lama, Asahan, Sumatra Utara, 18 Mei 1977; umur 42 tahun)\n" +
                "\nbeliau adalah seorang pendakwah dan ulama Indonesia yang sering mengulas berbagai macam persoalan agama, khususnya kajian ilmu hadis dan Ilmu fikih. Selain itu, ia juga banyak membahas mengenai nasionalisme dan berbagai masalah terkini yang sedang menjadi pembahasan hangat di kalangan masyarakat. Namanya dikenal publik karena Ilmu dan kelugasannya dalam memberikan penjelasan dalam menyampaikan dakwah yang disiarkan melalui saluran Youtube.\n" +
                "\nKajian-kajiannya yang baik dalam merangkai kata menjadi sebuah retorika dakwah, membuat ceramah Ustaz Abdul Somad begitu mudah dicerna dan mudah dipahami oleh berbagai kalangan masyarakat. Banyak dari ceramah Ustaz Abdul Somad yang mengulas berbagai macam persoalan agama. Dan bahkan bukan itu saja, ceramah Ustaz Abdul Somad juga banyak yang membahas mengenai masalah-masalah terkini, nasionalisme dan berbagai masalah yang sedang menjadi pembahasan hangat di kalangan masyarakat.\n" +
                "\nUstaz Abdul Somad menempuh pendidikan formal terakhir saat ini hingga jenjang master dalam bidang Ilmu Hadis, secara terturut-turut pendidikannya dapat dituliskan sebagai berikut:\n" +
                "\n\n" +
                "\n\t-SD Al-Washliyah, Medan, tamat 1990\n" +
                "\n\t-Madrasah Tsanawiyah Mu'allimin Al-Washliyah, Medan, tamat 1993\n" +
                "\n\t-Madrasah Aliyah Nurul Falah, Air Molek, In-hu, tamat 1996\n" +
                "\n\t-S1 Al-Azhar, Mesir, 2002\n" +
                "\n\t-S2 Dar El Hadith El Hassania, Kerajaan Maroko, 2006\n" +
                "\n\n" +
                "\nKarya ilmiah\n" +
                "\nTesis yang berjudul رجال الموطأ والصحيحين الذين ضعفهم النسائي في كتاب الضعفاء والمتروكين: جمعا ودراسة\n" +
                "\nTerjemahan (Arab–Indonesia)\n" +
                "\n\t-Perbuatan Maksiat Penyebab Kerusakan Rumah Tangga (Judul Asli: Al-Ma’ashi Tu’addi ila Al-Faqri wa Kharab Al-Buyut), Penulis: Majdi Fathi As-Sayyid. Diterbitkan oleh Pustaka Al-Kautsar, Jakarta, Maret 2008.\n" +
                "\n\t-55 Nasihat Perkawinan Untuk Perempuan, (Judul Asli: 55 Nashihat li al-banat qabla az-zawaj), Penulis: DR. Akram Thal’at, Dar at-Ta’if, Cairo. Diterbitkan oleh Penerbit Cendikia Sentra Muslim-Jakarta, April-2004.\n" +
                "\n\t-101 Kisah Orang-Orang Yang Dikabulkan Doanya (Judul Asli: 101 Qishash wa Qishah li Alladzina Istajaba Allah Lahum Ad-Du’a’, Majdi Fathi As-Sayyid. Diterbitkan oleh Pustaka Azzam – Jakarta, Desember 2004.\n" +
                "\n\t-30 Orang Dijamin Masuk Surga (Judul Asli: 30 al-mubasysyarun bi al-jannah), DR.Mustafa Murad, Dar al-Fajr li at-Turats,Cairo. Diterbitkan oleh Cendikia Sentra Muslim-Jakarta, Juli-2004.\n" +
                "\n\t-15 Sebab Dicabutnya Berkah (Judul Asli: 15 sabab min asbab naz’ al-barakah), Penulis: Abu Al-Hamd Abdul Fadhil, Dar ar-Raudhah-Cairo. Diterbitkan oleh Cendikia Sentra Muslim-Jakarta, Agustus-2004\n" +
                "\n\t-Indahnya Seks Setelah Menikah (Judul Asli: Syahr al-‘asal bi la khajal), DR. Aiman Al-Husaini, diterbitkan oleh Penerbit Pustaka Progresif, Jakarta, September 2004.\n" +
                "\n\t-Beberapa Kekeliruan Memahami Pernikahan (Judul Asli: Akhta’ fi mafhum az-zawaj, Muhammad bin Ibrahim Al-Hamd, diterbitkan oleh Penerbit Pustaka Progresif- Jakarta, September 2004.\n" +
                "\n\t-Sejarah Agama Yahudi (Judul Asli: Tarikh ad-Diyanah al-Yahudiyyah), diterbitkan oleh Pustaka al-Kautsar, Jakarta, Desember 2009."
        ,"al-Habib Umar bin Muhammad bin Salim bin Hafidz\n" +
                "\ndilahirkan pada hari Senin, 27 Mei 1963 M [Kalender Hijriyah: 4 Muharram 1383]\n" +
                "\nbeliau adalah seorang ulama dunia era modern. al-Habib ‘Umar kini tinggal di Tarim, Yaman di mana dia mengawasi perkembangan di Dar-al Musthafa dan berbagai sekolah lain yang telah dibangun di bawah manajemennya. Dia masih memegang peran aktif dalam dakwah agama Islam, sedemikian aktifnya sehingga dia meluangkan hampir sepanjang tahunnya mengunjungi berbagai negara di seluruh dunia demi melakukan kegiatan-kegiatan mulianya itu.\n" +
                "\n\tNasab beliau yaitu:\n" +
                "\nia adalah al-Habib ‘Umar putera dari Muhammad putera dari Salim putera dari Hafiz putera dari Abd-Allah putera dari Abi Bakr putera dari‘Aidarous putera dari al-Hussain putera dari al-Shaikh Abi Bakr putera dari Salim putera dari ‘Abd-Allah putera dari ‘Abd-al-Rahman putera dari ‘Abd-Allah putera dari al-Shaikh ‘Abd-al-Rahman al-Saqqaf putera dari Muhammad Maula al-Daweela putera dari ‘Ali putera dari ‘Alawi putera dari al-Faqih al-Muqaddam Muhammad putera dari ‘Ali putera dari Muhammad Sahib al-Mirbat putera dari ‘Ali Khali‘ Qasam putera dari ‘Alawi putera dari Muhammad putera dari ‘Alawi putera dari ‘Ubaidallah putera dari al-Imam al-Muhajir to Allah Ahmad putera dari ‘Isa putera dari Muhammad putera dari ‘Ali al-‘Uraidi putera dari Ja’far al-Sadiq putera dari Muhammad al-Baqir putera dari ‘Ali Zain al-‘Abidin putera dari Hussain sang cucu laki-laki, putera dari pasangan ‘Ali putera dari Abu Talib dan Fatimah al-Zahra puteri dari Rasul Muhammad Shallallahu 'Alaihi Wasallam.\n" +
                "\nDaftar Kitab Karangan\n" +
                "al-Habib Umar juga merupakan ulama yang produktif dalam menulis, di antara kitab karangan Ia adalah:\n" +
                "\n" +
                "\n1.Is'af at Thalibi\n" +
                "\n2.Ridha al-Khalaq bi bayan Makarimal Akhlaq\n" +
                "\n3.Taujihat at-Thullab\n" +
                "\n4.Syarah Mandzumah Sanad al-'Ulwi.\n" +
                "\n5.adz-Dzakirah al-Musyarrafah(Fiqih)\n" +
                "\n6.Dhiyaullami'bidzikri Maulid an-Nabi asy-Syafi'(Maulid Nabi Muhammad SAW)\n" +
                "\n7.Khuluquna\n" +
                "\n8.Khulasoh madad an-nabawiy(Dzikir)\n" +
                "\n9.Syarobu althohurfi dhikri siratu badril budur\n" +
                "\n10.Taujihat nabawiyah\n" +
                "\n11.Nur aliman(Aqidah)\n" +
                "\n12.Almukhtar syifa alsaqim\n" +
                "\n13.Al washatiah\n" +
                "\n14.Mamlakatul qa’ab wa al ‘adha’\n" +
                "\n15.Muhtar Ahadits (Hadits)\n" +
                "\n16.Durul Asas (Nahu)\n" +
                "\n17.Tsaqafatul Khatib (Panduan Khutbah)\n" +
                "\nKitab Maulid adh-Dhiya' al-Lami' merupakan karya al-Habib Umar paling monumental yang berisi syair pujian terhadap Rasulullah SAW, ummat islam Indonesia telah banyak mengenal dan membaca karya ini, yang juga mengenalnya dengan Maulid al-Habib Umar."
        ,"Munzir bin Fuad al-Musawa atau lebih dikenal dengan Munzir Al-Musawa atau Munzir (lahir di Cipanas, Cianjur, Jawa Barat, 23 Februari 1973 – meninggal di Jakarta, 15 September 2013 pada umur 40 tahun) adalah dikenal sebagai pimpinan Majelis Rasulullah SAW yang dakwahnya menjangkau berbagai wilayah di Indonesia, beberapa wilayah nusantara dan dunia. Dakwahnya yang menyentuh berbagai kalangan menjadikan ia banyak dicintai oleh Ummat Islam terutama di wilayah Jabodetabek dan di Nusantara. Munzir adalah murid yang begitu disayangi oleh gurunya Umar bin Hafidz ,sedangkan kalangan pemuda muslim yang mengenalnya tidak jarang menjadikan ia sebagai panutan ataupun idola dalam mengikuti ajaran Nabi Muhammad SAW.Dakwahnya di Indonesia juga tercatat sering di hadiri tokoh-tokoh nasional seperti Presiden Republik Indonesia, Susilo Bambang Yudhoyono, Suryadharma Ali , Fadel Muhammad, Fauzi Bowo dan lain-lain.\n" +
                "\\n-tSilsilah\n" +
                "\\nMunzir bin Fuad bin Abdurrahman bin Ali bin Abdurrahman bin Ali bin Aqil bin Ahmad bin Abdurrahman bin Umar bin Abdurrahman bin Sulaiman bin Yaasin bin Ahmad Al-Musawa bin Muhammad Muqallaf bin Ahmad bin Abubakar As Sakran bin Abdurrahman Assegaf bin Muhammad Mauladdawilah bin Ali bin Alwi Al-Ghayur bin Muhammad al-Faqih Muqaddam bin Ali bin Muhammad Shahib Mirbath bin Ali Khali' Qasim bin Alwi bin Muhammad bin Alwi bin Ubaidillah bin Ahmad al-Muhajir bin Isa Ar-Rumiy bin Muhammad Annaqib bin Ali Al-Uraidhiy bin Ja'far ash-Shadiq bin Muhammad al-Baqir bin Ali Zainal Abidin bin Hussein dari Fatimah az-Zahra Putri Rasulullah SAW.\n"
        ,"Ahmad Romiz bin fessel al-Banajri lahir dipurwokerto, 09 mei 1999\n" +
                "\nriwayat pendidikan adalah :\n" +
                "\nSD Negeri Brebes 03\n" +
                "\nSD Negeri 01 Kalierang\n" +
                "\nSMP Negeri 01 Bumiayu\n" +
                "\nSMA Negeri 02 Slawi\n" +
                "\nS1 Teknik Informatika (Universitas Teknologi Yogyakarta)\n" +
                "\nKarya yang pernah di buat:\n" +
                "\n-Asapku Nikmatku (lukis)\n" +
                "\n-Aku sang Munafik (tulis)\n" +
                "\n-Warna Digital (lukis)\n" +
                "\n-LAJUKA (laut ujung duka) [tulis]\n" +
                "\nMemilii hobby dan presatasi dalam robotika dengan mendapat juara 4 nasional dalam lomba ROV, menjadi pembina dalam lomba RC boat dengan mendapat jauara 1 nasional dan mendapat penghargaan mahasiswa pembina terbaik.\n"
        ,"Habib Muhammad Rizieq bin Hussein Shihab, Lc., M.A., DPMSS atau yang lebih akrab disapa Habib Rizieq (lahir di Jakarta, 24 Agustus 1965; umur 54 tahun)\n" +
                "\nbeliau adalah seorang tokoh Islam Indonesia yang dikenal sebagai pemimpin dan pendiri organisasi Front Pembela Islam beliaumerupakan ulama besar.\n" +
                "\nKarya\n" +
                "\n\tBuku\n" +
                "\n-Hancurkan Liberalisme, Tegakkan Syariat Islam, 2011.\n" +
                "\n-Wawasan Kebangsaan Menuju NKRI Bersyariah, 2012.\n" +
                "\n-Dialog FPI, Amar Ma'ruf Nahi Munkar\n" +
                "\n\tKarya lain\n" +
                "\nKumpulan Shalawat yang disusun oleh Habib Muhammad Rizieq Shihab\n" +
                "\n\nSetelah lulus sekolah dasar pada tahun 1975 di SDN 1 Petamburan, Tanah Abang, Jakarta Pusat, pada tahun 1976 Rizieq melanjutkan sekolah menengahnya ke SMP 40 Pejompongan, Jakarta Pusat. Namun karena jarak sekolah dengan rumahnya di Petamburan terlalu jauh, ia kemudian dipindahkan ke sekolah yang relatif lebih dekat dengan tempat tinggalnya, yaitu SMP Kristen Bethel Petamburan dan lulus tahun 1979. Ia kemudian melanjutkan sekolahnya di SMA Negeri 4 Jakarta di Gambir, namun lulus dari SMA Islamic Village Tangerang pada tahun 1982.\n" +
                "\nPada tahun 1983, Rizieq mengambil kelas bahasa Arab di Lembaga Ilmu Pengetahuan Islam dan Arab (LIPIA). Namun setelah satu tahun menempuh studi, ia mendapat tawaran beasiswa dari Organisasi Kerjasama Islam (OKI) untuk kuliah di Arab Saudi. Ia pun melanjutkan program sarjana jurusan Studi Agama Islam (Fiqih dan Ushul Fiqh) ke King Saud University yang ditempuhnya selama empat tahun. Pada tahun 1990, Habib Rizieq dinyatakan lulus, lengkap dengan predikat Cum Laude.\n" +
                "\nHabib Rizieq sempat mengambil program pascasarjana di Universitas Islam Internasional Malaysia selama satu tahun, setelah itu ia kembali ke Indonesia sebelum magisternya selesai karena alasan biaya. Setelah beberapa tahun, akhirnya ia mampu melanjutkan pendidikannya di bidang Syari'ah dan meraih gelar Master of Arts (M.A.) pada tahun 2008 di Universitas Malaya dengan tesis berjudul \"Pengaruh Pancasila Terhadap Pelaksanaan Syariat Islam di Indonesia\".\n" +
                "\nPada tahun 2012, Habib Rizieq kembali ke Malaysia dan melanjutkan program pendidikan doktor dalam program Dakwah dan Manajemen di Fakultas Kepemimpinan dan Pengurusan Universiti Sains Islam Malaysia (USIM)[10]. Saat ini ia sedang menyelesaikan disertasinya yang berjudul \"مناهج التميز بين الأصول والفروع عند أهل السنة والجماعة\" (Perbedaan Asal dan Cabang Ahlussunah Wal Jama'ah) di bawah pengawasan Prof. Dr. Kamaluddin Nurdin Marjuni dan Dr. Ahmed Abdul Malek dari Nigeria."
        ,"Habib Syech Abdul Qodir Assegaf (lahir di Kota Surakarta, 20 September 1961; umur 58 tahun)merupakan putra Habib Abdul qadir bin Abdurrahman Assegaf, seorang tokoh alim yg pernah berguru terhadap sejumlah habaib di Kota Surakarta yaitu Al Habib Anis bin Alwi al-Habsyi beliau juga adik kandung dari imam Masjid Jami' Assegaf di Kecamatan Pasar Kliwon Kota Surakarta yaitu Al Habib Muhammad Jamal bin Abdul Qodir bin Abdurrahman Assegaf. Beliau merupakan penyanyi sholawat religius bersama grup Ahbaabul Musthofa.\n" +
                "\nLagu sholawat Habib Syech memang tergolong unik. Dengan arransemen ulang dari kitab sholawat yang berisikan sekitar 500-san syair, Habib Syech mampu mengaransemen lagu sholawat dengan indah dan sesuai harapan jamaah.\n" +
                "\nDi dalam lagu sholawat Habib Syech sendiri juga tidak melulu berbahasa Arab. Bahkan, ada beberapa lagu yang berbahasa Indonesia dan khususnya berbahasa Jawa. Dengan adanya variasi bahasa tersebut, sholawat Habib Syech menjadi lebih mengena dan pesan yang ada dalam shalawat bisa tersampaikan.\n" +
                "\nLagu-lagu sholawat Habib Syech banyak digemari bukan hanya kalangan atas, namun juga kalangan bawah dari santri sampai pejabat. Terlebih bila sholawat diimbuhi dengan variasai bahasa Jawa, masyarakat sangat senang dan lebih terasa jadi orang Jawa.\n" +
                "\nBila Anda mencermati music Habib Syech, hal yang paing sering didengar ada dua macam yakni music Habib Syech yang murni rebana, dengan music Habib Syech yang menggunakan alat music moden seperti keyboard dll.\n" +
                "\nAda perbedaan penggunaan music di dalam lantunan sholawat Habib Syech. Model alat music rebana lebih digunakan di saat tampil live di atas panggung. Begitu sebaliknya, bila di dalam kaset maupun VCD, dua-duanya digunakan yakni perpaduan antara rebana dan alat music modern.\n" +
                "\nSo, cobalah nikmati perpaduan apik antara alat music rebana dengan alat music modern. Perpaduan music tersebut semakin apik ketika ditambah suara vocal cirri khas Habib Syech dan backing vocal dari Ahbabul Musthofa.\n" +
                "\nDi tahun 2014, label RPM mempersembahkan sebuah album special ramadhan yakni \"The Best Sholawat\" yang album tersebut berisikan lagu lagu sholawat Habib Syech yang populer dinyanyikan pada saat konser maupun perform berbagai kota, yang diisikan 9 lagu pilihan dalam bentuk digital maupun fisik yang dirilis dalam Volume 1, 2, 3, 4. Album tersebut dianggap special karena albumnya merupakan album the best sholawat karya karya dari Habib Syech.\n" +
                "\nDi tahun 2015, dirilislah album sholawat \"Untaian Nada Rindu Al Musthofa\" yang album nya berisikan 6 lagu dengan lagu utama \"Alangkah Indahnya/Ya Rasulallah\" yang lagu tersebut re-make dari grup nasyid asal Malaysia yakni Raihan."


           )

    private val fotoTokoh = intArrayOf(
        R.drawable.aa,
        R.drawable.gmb2,
        R.drawable.gmb3,
        R.drawable.gmb4,
        R.drawable.gmb5,
        R.drawable.gmb6,
        R.drawable.gmb7,
        R.drawable.gmb8,
        R.drawable.gmb9,
        R.drawable.gmb10
    )

    val listData: ArrayList<Tokoh>
        get() {
            val list = arrayListOf<Tokoh>()
            for (position in namaTokohk.indices) {
                val tokoh = Tokoh()
                tokoh.name = namaTokohk[position]
                tokoh.detail = detaillTokoh[position]
                tokoh.photo = fotoTokoh[position]
                list.add(tokoh)
            }
            return list
        }
}