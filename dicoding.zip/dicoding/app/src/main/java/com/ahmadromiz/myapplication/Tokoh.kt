package com.ahmadromiz.myapplication

class Tokoh (
    var name: String = "",
    var detail: String = "",
    var photo: Int = 0
)