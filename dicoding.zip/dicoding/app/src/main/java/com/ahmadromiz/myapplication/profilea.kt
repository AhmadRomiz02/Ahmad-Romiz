package com.ahmadromiz.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.appcompat.app.ActionBar

class profilea : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profilea)

        if (supportActionBar != null) {
            (supportActionBar as ActionBar).title = "Tentang"
        }
    }
}
