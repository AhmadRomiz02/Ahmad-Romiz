package com.ahmadromiz.myapplication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.ahmadromiz.myapplication.DataTokoh
import com.ahmadromiz.myapplication.R

class MainActivity : AppCompatActivity() {
    private lateinit var vtokoh: RecyclerView
    private var list: ArrayList<Tokoh> = arrayListOf()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        vtokoh = findViewById(R.id.rv_tokoh)
        vtokoh.setHasFixedSize(true)
        list.addAll(DataTokoh.listData)
        showRecyclerList()
    }
    private fun showRecyclerList() {
        vtokoh.layoutManager = LinearLayoutManager(this)
        val adapter = Adapter(list)
        vtokoh.adapter = adapter

        adapter.setOnItemClickCallback (object : Adapter.OnItemClickCallback {
            override fun onItemClicked(data: Tokoh) {
                showSelectedTokoh(data)
            }
        })
    }


    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        setMode(item.itemId)
        return super.onOptionsItemSelected(item)
    }

    private fun setMode(selectedMode: Int) {
        when (selectedMode) {
            R.id.action_list -> {
                showRecyclerList()
            }

            R.id.data -> {
                val IntentAbout = Intent(this, profilea::class.java)
                startActivity(IntentAbout)
            }


        }
    }
    private fun showSelectedTokoh(gm : Tokoh) {
        Toast.makeText(this, gm.name, Toast.LENGTH_SHORT).show()
    }
}
